// ==============JQUERY================
$(document).ready(function(){
    $(".list li a").click(function(){
        // Change The Color li in Sidebar
        $(this).parent().siblings().removeClass('do');
        $(this).parent().addClass('do');
    })
    
    // dropDown Click sidebar
    $(".menu-btn").click(function(){
        $(".menu-btn i").toggleClass("active");
        $(".sidebar").toggleClass("active");
        $(".menu-logo").toggleClass("active");
        $(".sidebar .list li span").toggleClass("active");
        $(".sidebar .date-time").toggleClass("active");
        $(".sidebar .list .top-list").toggleClass("active");
        $(".sidebar .list").toggleClass("active");

    })
    
    counter(); // call counter function
    function counter() {
     $('.num').each(function () {
         $(this).prop('Counter', 0).animate({
             Counter: $(this).text()
         }, {
             duration: 5000
             , easing: 'swing'
             , step: function (now) {
                 $(this).text(Math.ceil(now));
             }
         });
     });
    }
}) 


// =============JAVASCRIPT=================
// Show time and date in sidebar

// code Date
const now = new Date();
const option = {
    month:'long',
    year:'numeric',
    day:'numeric',
    
}
const date = new Intl.DateTimeFormat("fa-IR",option).format(now);
let dateing = document.querySelector(".date-side");
dateing.innerText = date;

// code time
let timing =document.querySelector(".time-side");
 timing.innerText = new Date().toLocaleTimeString("fa-IR",{hour:'numeric',minute:'numeric'});
setInterval(() => {
    timing.textContent = new Date().toLocaleTimeString("fa-IR",{hour:'numeric',minute:'numeric'});
}, 1000 * 60);
